# StudyFlow - Intelligent Student Productivity Platform

StudyFlow is a comprehensive productivity platform designed specifically for students. Built with modern web technologies, it helps students manage their time, track habits, set goals, and optimize their study sessions with AI-powered features.

## 🚀 Features

### 📅 Smart Calendar & Scheduling
- Color-coded schedule tailored to your classes and commitments
- AI-powered study planner that suggests optimal time slots
- Integration with Google Classroom for automatic assignment imports
- Monthly and hourly calendar views

### ✅ Task Management
- Priority-based task organization (Low, Medium, High, Urgent)
- Matrix-based system to beat procrastination
- Task categorization and tagging
- Progress tracking and completion analytics

### 🎯 Focus & Productivity
- Pomodoro timer with adaptive breaks
- Customizable focus and break durations
- Session tracking and analytics
- Ambient study environment options

### 📊 Analytics & Insights
- Visual insights into study patterns
- Completion trends and productivity metrics
- Weekly and monthly progress reports
- Goal achievement tracking

### 🔥 Habit Tracker
- Daily, weekly, and monthly habit tracking
- Streak counters and motivation systems
- Progress visualization
- Customizable habit categories

### 🎯 Goal Setting
- Academic milestone tracking
- Progress visualization with milestones
- Smart deadline management
- Achievement badges and rewards

### 🤖 AI Study Assistant
- Intelligent scheduling based on energy levels
- Personalized study recommendations
- Task duration estimation
- Learning pattern optimization

### 📱 User Experience
- Dark/light theme support
- Responsive design for all devices
- Intuitive sidebar navigation
- Real-time notifications and reminders

## 🛠 Technology Stack

### Frontend
- **React 18** - Modern React with hooks and concurrent features
- **TypeScript** - Type-safe development with comprehensive type definitions
- **Vite** - Fast build tool and development server
- **React Router** - Client-side routing with protected routes
- **React Query** - Server state management and caching
- **shadcn/ui** - Beautiful, accessible UI components
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Consistent icon system
- **React Hook Form** - Form handling with validation
- **Recharts** - Data visualization and charts

### Backend & Database
- **Supabase** - Open-source Firebase alternative
  - PostgreSQL database
  - Real-time subscriptions
  - Authentication system
  - Edge functions for serverless compute
  - Row-level security

### Development Tools
- **ESLint** - Code linting and formatting
- **PostCSS** - CSS processing and optimization
- **Autoprefixer** - CSS vendor prefixing
- **TypeScript Compiler** - Type checking and compilation

## 📦 Installation & Setup

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn package manager
- Git

### Local Development Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/studyflow.git
   cd studyflow
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   ```bash
   # Copy the example environment file
   cp .env.example .env.local
   
   # Add your Supabase configuration
   # Get these values from your Supabase project dashboard
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

4. **Database Setup**
   ```bash
   # Apply database migrations
   npx supabase db push
   
   # Start local Supabase services
   npx supabase start
   ```

5. **Start Development Server**
   ```bash
   npm run dev
   ```

   The application will be available at `http://localhost:5173`

### Environment Variables

Create a `.env.local` file in the root directory:

```env
# Supabase Configuration
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# Optional: Google Classroom Integration
VITE_GOOGLE_CLIENT_ID=your-google-client-id

# Optional: Analytics (if enabled)
VITE_ANALYTICS_ID=your-analytics-id
```

## 🗄 Database Schema

The application uses the following main tables:

### `tasks`
- Student assignments and to-do items
- Priority levels, due dates, categories
- Progress tracking and completion status

### `habits`
- Daily, weekly, monthly habits
- Streak tracking and completion data
- Custom frequency settings

### `goals`
- Academic and personal goals
- Milestones and progress tracking
- Target dates and achievement status

### `routines`
- Study and daily routines
- Step-by-step breakdown
- Time-based scheduling

### `focus_sessions`
- Pomodoro and focus session data
- Duration tracking and completion status
- Productivity analytics

### `calendar_events`
- Scheduled study sessions and events
- Recurring patterns and reminders
- Integration with external calendars

## 🔧 Development Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Build for development (with dev tools)
npm run build:dev

# Preview production build
npm run preview

# Run linting
npm run lint

# Fix linting issues
npm run lint:fix
```

## 🚀 Deployment

### Production Deployment

1. **Build the application**
   ```bash
   npm run build
   ```

2. **Deploy to your preferred platform**
   - **Vercel**: Connect your GitHub repository and deploy
   - **Netlify**: Drag and drop the `dist` folder
   - **AWS S3**: Upload static files to S3 bucket
   - **Supabase Hosting**: Use Supabase's built-in hosting

3. **Environment Configuration**
   - Set production environment variables in your hosting platform
   - Configure your Supabase project for production use
   - Set up custom domains and SSL certificates

### Docker Deployment

```dockerfile
# Use the official Node.js runtime
FROM node:18-alpine

# Set working directory
WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy built application
COPY dist ./dist

# Serve the application
CMD ["npm", "run", "preview", "--", "--host", "0.0.0.0"]
```

## 🧪 Testing

### Running Tests

```bash
# Run unit tests
npm run test

# Run integration tests
npm run test:integration

# Run end-to-end tests
npm run test:e2e

# Run tests with coverage
npm run test:coverage
```

### Test Structure

- **Unit Tests**: Component logic and utility functions
- **Integration Tests**: API calls and database operations
- **E2E Tests**: Full user workflows and interactions

## 📊 Performance Optimization

### Built-in Optimizations
- Code splitting with lazy loading
- Bundle size optimization
- Image optimization and lazy loading
- Service worker for offline support

### Monitoring Performance
- React DevTools Profiler
- Chrome DevTools Performance tab
- Bundle analyzer with `npm run analyze`

## 🔒 Security Features

- Row-level security (RLS) in Supabase
- JWT token authentication
- Input validation and sanitization
- XSS protection
- CORS configuration
- Rate limiting (Supabase Edge Functions)

## 🌐 API Documentation

### Supabase Edge Functions

The application includes several edge functions:

- `ai-study-planner`: Intelligent scheduling based on user data
- `estimate-task-duration`: ML-powered duration predictions
- `google-classroom-auth`: OAuth integration for Google Classroom
- `send-notifications`: Email and push notification delivery
- `study-assistant`: AI-powered study recommendations
- `suggest-time-slots`: Optimal study time suggestions

### API Rate Limits

- Anonymous requests: 100 requests/hour
- Authenticated requests: 1000 requests/hour
- Edge functions: 10,000 invocations/month (free tier)

## 🤝 Contributing

We welcome contributions! Please follow these steps:

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/amazing-feature
   ```
3. **Make your changes**
4. **Add tests if applicable**
5. **Commit your changes**
   ```bash
   git commit -m 'Add amazing feature'
   ```
6. **Push to the branch**
   ```bash
   git push origin feature/amazing-feature
   ```
7. **Open a Pull Request**

### Code Style Guidelines
- Use TypeScript for all new code
- Follow the existing component structure
- Add proper error handling and loading states
- Include accessibility features
- Write meaningful commit messages

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support & Community

- **Documentation**: [StudyFlow Docs](https://docs.studyflow.app)
- **Discord Community**: [Join our Discord](https://discord.gg/studyflow)
- **Twitter**: [@StudyFlowApp](https://twitter.com/studyflowapp)
- **Email**: support@studyflow.app

## 🗺 Roadmap

### Upcoming Features
- [ ] Mobile app (React Native)
- [ ] Advanced AI recommendations
- [ ] Group study sessions
- [ ] Flashcard integration
- [ ] Note-taking system
- [ ] Integration with more learning platforms
- [ ] Advanced analytics dashboard
- [ ] Offline mode with sync
- [ ] Voice commands for hands-free operation

### Beta Features
- [ ] Study group collaboration
- [ ] AI-generated practice questions
- [ ] Performance predictions
- [ ] Social learning features

## 📈 Analytics & Metrics

Track your productivity with comprehensive analytics:

- Study hours per day/week/month
- Task completion rates
- Habit consistency scores
- Goal achievement percentages
- Focus session effectiveness
- Productivity trends over time

## 🔧 Customization

### Themes
- Light theme (default)
- Dark theme
- System preference
- Custom color schemes (coming soon)

### Notifications
- Email notifications
- Push notifications (PWA)
- In-app reminders
- Custom reminder times

### Study Preferences
- Focus duration customization
- Break interval settings
- Daily study goals
- Productivity hour preferences

---

Built with ❤️ for students everywhere. Let's make learning more productive and enjoyable together!

**StudyFlow** - Master Your Time, Ace Your Goals 🎯