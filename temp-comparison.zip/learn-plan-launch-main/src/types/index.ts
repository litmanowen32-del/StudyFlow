// Application-wide type definitions
// Replace all 'any[]' usage with proper TypeScript types

export interface User {
  id: string;
  email: string;
  name?: string;
  avatar_url?: string;
  created_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'todo' | 'in_progress' | 'completed' | 'cancelled';
  due_date?: string;
  estimated_duration?: number;
  actual_duration?: number;
  category?: string;
  tags?: string[];
  created_at: string;
  updated_at: string;
}

export interface Habit {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  frequency: 'daily' | 'weekly' | 'monthly';
  target_count: number;
  current_streak: number;
  best_streak: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface HabitEntry {
  id: string;
  habit_id: string;
  completed_at: string;
  notes?: string;
}

export interface Routine {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  time_of_day: 'morning' | 'afternoon' | 'evening' | 'night';
  duration_minutes: number;
  steps: RoutineStep[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface RoutineStep {
  id: string;
  routine_id: string;
  step_number: number;
  title: string;
  description?: string;
  duration_minutes: number;
  is_completed: boolean;
}

export interface Goal {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  target_date: string;
  progress: number;
  status: 'active' | 'completed' | 'paused' | 'cancelled';
  category: string;
  milestones: Milestone[];
  created_at: string;
  updated_at: string;
}

export interface Milestone {
  id: string;
  goal_id: string;
  title: string;
  description?: string;
  target_date: string;
  is_completed: boolean;
  created_at: string;
}

export interface FocusSession {
  id: string;
  user_id: string;
  duration_minutes: number;
  session_type: 'focus' | 'break';
  start_time: string;
  end_time?: string;
  is_completed: boolean;
  notes?: string;
}

export interface CalendarEvent {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  start_time: string;
  end_time: string;
  event_type: 'study' | 'class' | 'exam' | 'assignment' | 'personal' | 'other';
  location?: string;
  is_recurring: boolean;
  recurrence_pattern?: string;
  color?: string;
  created_at: string;
  updated_at: string;
}

export interface StudyAnalytics {
  total_study_hours: number;
  tasks_completed: number;
  goals_achieved: number;
  productivity_score: number;
  focus_sessions_completed: number;
  average_focus_duration: number;
  habit_completion_rate: number;
  weekly_progress: WeeklyProgress[];
}

export interface WeeklyProgress {
  week_start: string;
  study_hours: number;
  tasks_completed: number;
  habits_completed: number;
}

export interface NotificationPreferences {
  id: string;
  user_id: string;
  task_reminders: boolean;
  habit_reminders: boolean;
  goal_deadlines: boolean;
  focus_reminders: boolean;
  email_notifications: boolean;
  push_notifications: boolean;
  reminder_time: string; // HH:MM format
}

export interface UserSettings {
  id: string;
  user_id: string;
  theme: 'light' | 'dark' | 'system';
  language: string;
  timezone: string;
  focus_duration: number; // in minutes
  break_duration: number; // in minutes
  daily_study_goal: number; // in hours
  week_start_day: 'monday' | 'sunday';
  created_at: string;
  updated_at: string;
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  count: number;
  page: number;
  pages: number;
  has_more: boolean;
}

// Form types
export interface CreateTaskInput {
  title: string;
  description?: string;
  priority: Task['priority'];
  due_date?: string;
  estimated_duration?: number;
  category?: string;
  tags?: string[];
}

export interface UpdateTaskInput extends Partial<CreateTaskInput> {
  status?: Task['status'];
}

export interface CreateHabitInput {
  name: string;
  description?: string;
  frequency: Habit['frequency'];
  target_count: number;
}

export interface CreateRoutineInput {
  name: string;
  description?: string;
  time_of_day: Routine['time_of_day'];
  duration_minutes: number;
  steps: Omit<RoutineStep, 'id' | 'routine_id' | 'is_completed'>[];
}

export interface CreateGoalInput {
  title: string;
  description?: string;
  target_date: string;
  category: string;
  milestones?: Omit<Milestone, 'id' | 'goal_id' | 'is_completed' | 'created_at'>[];
}

// Chart and analytics types
export interface ChartDataPoint {
  label: string;
  value: number;
  date?: string;
}

export interface ProductivityMetrics {
  date: string;
  hours_studied: number;
  tasks_completed: number;
  habits_completed: number;
  focus_sessions: number;
  productivity_score: number;
}

// Error types
export interface AppError {
  code: string;
  message: string;
  details?: any;
}

// Component prop types
export interface BaseComponentProps {
  className?: string;
  children?: React.ReactNode;
}

export interface LoadingState {
  isLoading: boolean;
  error?: AppError;
}

// Utility types
export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;