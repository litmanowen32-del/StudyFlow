import { useState, useEffect } from 'react';
import { Calendar, ExternalLink, Clock, AlertCircle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { GoogleClassroomAssignment } from '@/types/google';

interface GoogleCalendarEventsProps {
  onAssignmentClick?: (assignment: GoogleClassroomAssignment) => void;
}

const GoogleCalendarEvents = ({ onAssignmentClick }: GoogleCalendarEventsProps) => {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<GoogleClassroomAssignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    if (user) {
      loadGoogleAssignments();
    }
  }, [user]);

  const loadGoogleAssignments = async () => {
    try {
      setLoading(true);
      
      // Check if Google Classroom is connected
      const { data: settings } = await supabase
        .from('user_settings')
        .select('google_classroom_connected')
        .eq('user_id', user?.id)
        .single();

      setIsConnected(settings?.google_classroom_connected || false);

      if (!settings?.google_classroom_connected) {
        setAssignments([]);
        return;
      }

      // Load Google Classroom assignments
      const { data: assignments, error } = await supabase
        .from('google_classroom_assignments')
        .select('*')
        .eq('user_id', user?.id)
        .order('due_date', { ascending: true })
        .limit(10);

      if (error) throw error;

      // Filter out completed assignments
      const activeAssignments = (assignments || []).filter(
        assignment => assignment.state !== 'TURNED_IN' && assignment.state !== 'RETURNED'
      );

      setAssignments(activeAssignments as GoogleClassroomAssignment[]);
    } catch (error) {
      console.error('Error loading Google assignments:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDaysUntilDue = (dueDate: string, dueTime?: string) => {
    if (!dueDate) return null;
    
    const dueDateTime = dueTime 
      ? new Date(`${dueDate}T${dueTime}`)
      : new Date(dueDate);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    dueDateTime.setHours(0, 0, 0, 0);
    
    const diffTime = dueDateTime.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  const getDueDateColor = (daysUntil: number | null) => {
    if (daysUntil === null) return 'default';
    if (daysUntil < 0) return 'destructive';
    if (daysUntil === 0) return 'destructive';
    if (daysUntil <= 1) return 'destructive';
    if (daysUntil <= 3) return 'warning';
    return 'secondary';
  };

  const getDueDateText = (daysUntil: number | null) => {
    if (daysUntil === null) return 'No due date';
    if (daysUntil < 0) return 'Overdue';
    if (daysUntil === 0) return 'Due today';
    if (daysUntil === 1) return 'Due tomorrow';
    return `Due in ${daysUntil} days`;
  };

  if (!isConnected) {
    return (
      <Card className="p-6 shadow-soft">
        <div className="text-center space-y-4">
          <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
            <Calendar className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">Google Classroom Not Connected</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Connect your Google Classroom account to automatically sync assignments to your calendar.
            </p>
            <Button variant="outline" size="sm">
              Connect Google Classroom
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="p-6 shadow-soft">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="h-5 w-5 bg-blue-100 rounded animate-pulse" />
            <div className="h-4 w-32 bg-muted rounded animate-pulse" />
          </div>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-3 border rounded-lg">
                <div className="space-y-2">
                  <div className="h-4 w-3/4 bg-muted rounded animate-pulse" />
                  <div className="h-3 w-1/2 bg-muted rounded animate-pulse" />
                  <div className="h-3 w-1/4 bg-muted rounded animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    );
  }

  if (assignments.length === 0) {
    return (
      <Card className="p-6 shadow-soft">
        <div className="text-center space-y-4">
          <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center mx-auto">
            <AlertCircle className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">All Caught Up!</h3>
            <p className="text-sm text-muted-foreground">
              You have no pending assignments from Google Classroom.
            </p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 shadow-soft">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-blue-600" />
            <h3 className="font-semibold text-foreground">Google Classroom Assignments</h3>
          </div>
          <Badge variant="secondary" className="text-xs">
            {assignments.length} pending
          </Badge>
        </div>

        <Separator />

        {/* Assignments List */}
        <div className="space-y-3">
          {assignments.map((assignment) => {
            const daysUntil = getDaysUntilDue(assignment.due_date, assignment.due_time);
            const dueDateColor = getDueDateColor(daysUntil);
            
            return (
              <div
                key={assignment.id}
                className="p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => onAssignmentClick?.(assignment)}
              >
                <div className="space-y-2">
                  {/* Assignment Title and Course */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground text-sm truncate">
                        {assignment.title}
                      </h4>
                      <p className="text-xs text-muted-foreground">
                        {assignment.course_name}
                      </p>
                    </div>
                    <Badge variant={dueDateColor} className="text-xs whitespace-nowrap">
                      {getDueDateText(daysUntil)}
                    </Badge>
                  </div>

                  {/* Assignment Details */}
                  {assignment.description && (
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {assignment.description}
                    </p>
                  )}

                  {/* Due Date and Points */}
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    {assignment.due_date && (
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>
                          {new Date(assignment.due_date).toLocaleDateString()}
                          {assignment.due_time && ` at ${assignment.due_time}`}
                        </span>
                      </div>
                    )}
                    {assignment.max_points && (
                      <span>{assignment.max_points} points</span>
                    )}
                  </div>

                  {/* Assignment Link */}
                  {assignment.link && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        window.open(assignment.link, '_blank');
                      }}
                    >
                      <ExternalLink className="h-3 w-3 mr-1" />
                      View Assignment
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="pt-2">
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => window.open('https://classroom.google.com', '_blank')}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Open Google Classroom
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default GoogleCalendarEvents;