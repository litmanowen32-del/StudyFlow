import { cn } from "@/lib/utils";

function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("animate-pulse rounded-md bg-muted", className)} {...props} />;
}

// Task skeleton for loading state
export const TaskSkeleton = () => (
  <div className="p-4 border rounded-lg">
    <div className="flex items-start gap-3">
      <Skeleton className="h-5 w-5 mt-1 rounded" />
      <div className="flex-1 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <Skeleton className="h-5 w-48 rounded" />
          <div className="flex items-center gap-2">
            <Skeleton className="h-6 w-16 rounded-full" />
            <Skeleton className="h-7 w-7 rounded" />
          </div>
        </div>
        <Skeleton className="h-4 w-full rounded" />
        <div className="flex items-center gap-4">
          <Skeleton className="h-3 w-20 rounded" />
          <Skeleton className="h-3 w-24 rounded" />
        </div>
      </div>
    </div>
  </div>
);

// Habit skeleton for loading state
export const HabitSkeleton = () => (
  <div className="p-4 border rounded-lg">
    <div className="flex items-center justify-between">
      <div className="space-y-2">
        <Skeleton className="h-5 w-32 rounded" />
        <Skeleton className="h-4 w-48 rounded" />
      </div>
      <div className="flex items-center gap-2">
        <Skeleton className="h-8 w-8 rounded-full" />
        <Skeleton className="h-7 w-7 rounded" />
      </div>
    </div>
  </div>
);

// Analytics skeleton for loading state
export const AnalyticsSkeleton = () => (
  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
    {Array.from({ length: 4 }).map((_, i) => (
      <div key={i} className="p-6 border rounded-lg">
        <Skeleton className="h-8 w-16 rounded mb-2" />
        <Skeleton className="h-4 w-24 rounded" />
      </div>
    ))}
  </div>
);

// Calendar skeleton for loading state
export const CalendarSkeleton = () => (
  <div className="border rounded-lg p-4">
    <div className="grid grid-cols-7 gap-2 mb-4">
      {Array.from({ length: 7 }).map((_, i) => (
        <Skeleton key={i} className="h-8 w-full rounded" />
      ))}
    </div>
    <div className="grid grid-cols-7 gap-2">
      {Array.from({ length: 35 }).map((_, i) => (
        <Skeleton key={i} className="h-20 w-full rounded" />
      ))}
    </div>
  </div>
);

// Goal skeleton for loading state
export const GoalSkeleton = () => (
  <div className="p-4 border rounded-lg">
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Skeleton className="h-5 w-40 rounded" />
        <Skeleton className="h-6 w-16 rounded-full" />
      </div>
      <Skeleton className="h-2 w-full rounded" />
      <div className="flex items-center justify-between text-sm">
        <Skeleton className="h-3 w-24 rounded" />
        <Skeleton className="h-3 w-20 rounded" />
      </div>
    </div>
  </div>
);

export { Skeleton };
