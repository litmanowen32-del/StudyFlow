import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  School, 
  Calendar, 
  Sync, 
  CheckCircle, 
  AlertCircle, 
  Settings,
  Loader2,
  ExternalLink
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import GoogleClassroomService from '@/services/googleClassroom';

interface GoogleAuthStatus {
  isConnected: boolean;
  email?: string;
  lastSync?: string;
  autoSyncEnabled: boolean;
}

const GoogleAuth = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [authStatus, setAuthStatus] = useState<GoogleAuthStatus>({
    isConnected: false,
    autoSyncEnabled: false,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [coursesCount, setCoursesCount] = useState(0);
  const [assignmentsCount, setAssignmentsCount] = useState(0);

  // Load auth status from localStorage and database
  useEffect(() => {
    if (user) {
      loadAuthStatus();
      checkGoogleCredentials();
    }
  }, [user]);

  const loadAuthStatus = async () => {
    try {
      const { data: settings } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (settings) {
        setAuthStatus({
          isConnected: settings.google_classroom_connected || false,
          email: settings.google_email || undefined,
          lastSync: settings.last_sync_date || undefined,
          autoSyncEnabled: settings.auto_sync_enabled || false,
        });
      }
    } catch (error) {
      console.error('Error loading auth status:', error);
    }
  };

  const checkGoogleCredentials = async () => {
    try {
      const { data } = await supabase.functions.invoke('google-classroom-auth', {
        body: { userId: user?.id }
      });

      if (data?.hasCredentials) {
        // Try to initialize the service with stored credentials
        const response = await supabase.functions.invoke('get-google-tokens', {
          body: { userId: user?.id }
        });

        if (response.data?.tokens) {
          GoogleClassroomService.initialize(
            response.data.tokens.access_token,
            response.data.tokens.refresh_token,
            response.data.tokens.expires_in
          );
          
          // Get counts
          await fetchGoogleDataCounts();
        }
      }
    } catch (error) {
      console.error('Error checking Google credentials:', error);
    }
  };

  const fetchGoogleDataCounts = async () => {
    try {
      const courses = await GoogleClassroomService.getCourses();
      setCoursesCount(courses.length);
      
      const assignments = await GoogleClassroomService.getAllAssignments();
      setAssignmentsCount(assignments.length);
    } catch (error) {
      console.error('Error fetching Google data counts:', error);
    }
  };

  const handleGoogleAuth = async () => {
    if (!import.meta.env.VITE_GOOGLE_CLIENT_ID) {
      toast({
        title: 'Google Integration Not Configured',
        description: 'Please configure Google OAuth credentials in your environment.',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      // Initialize Google OAuth
      const authWindow = window.open(
        `https://accounts.google.com/oauth/authorize?` +
        `client_id=${import.meta.env.VITE_GOOGLE_CLIENT_ID}&` +
        `redirect_uri=${encodeURIComponent(window.location.origin + '/auth/google/callback')}&` +
        `response_type=code&` +
        `scope=https://www.googleapis.com/auth/classroom.courses.readonly https://www.googleapis.com/auth/classroom.coursework.me.readonly https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events&` +
        `access_type=offline&` +
        `prompt=consent`,
        'google-auth',
        'width=500,height=600'
      );

      // Listen for auth completion
      const messageHandler = async (event: MessageEvent) => {
        if (event.origin !== window.location.origin) return;
        
        if (event.data.type === 'GOOGLE_AUTH_SUCCESS') {
          authWindow?.close();
          window.removeEventListener('message', messageHandler);
          
          // Store credentials in database
          await supabase.functions.invoke('store-google-credentials', {
            body: {
              userId: user?.id,
              authCode: event.data.code,
            }
          });

          // Get tokens and initialize service
          const tokenResponse = await supabase.functions.invoke('exchange-google-code', {
            body: { code: event.data.code }
          });

          if (tokenResponse.data?.tokens) {
            GoogleClassroomService.initialize(
              tokenResponse.data.tokens.access_token,
              tokenResponse.data.tokens.refresh_token,
              tokenResponse.data.tokens.expires_in
            );
          }

          // Update user settings
          await supabase
            .from('user_settings')
            .upsert({
              user_id: user?.id,
              google_classroom_connected: true,
              google_email: event.data.email,
              last_sync_date: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            });

          setAuthStatus(prev => ({
            ...prev,
            isConnected: true,
            email: event.data.email,
            lastSync: new Date().toISOString(),
          }));

          // Fetch data counts
          await fetchGoogleDataCounts();

          toast({
            title: 'Google Classroom Connected!',
            description: 'You can now sync your assignments to the calendar.',
          });
        } else if (event.data.type === 'GOOGLE_AUTH_ERROR') {
          authWindow?.close();
          window.removeEventListener('message', messageHandler);
          
          toast({
            title: 'Authentication Failed',
            description: event.data.error || 'Failed to connect to Google Classroom.',
            variant: 'destructive',
          });
        }
      };

      window.addEventListener('message', messageHandler);
    } catch (error) {
      console.error('Error during Google auth:', error);
      toast({
        title: 'Authentication Error',
        description: 'Failed to connect to Google Classroom. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDisconnect = async () => {
    setIsLoading(true);
    try {
      // Clear stored credentials
      await supabase.functions.invoke('clear-google-credentials', {
        body: { userId: user?.id }
      });

      // Update user settings
      await supabase
        .from('user_settings')
        .update({
          google_classroom_connected: false,
          google_email: null,
          auto_sync_enabled: false,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user?.id);

      GoogleClassroomService.clearAuth();

      setAuthStatus({
        isConnected: false,
        autoSyncEnabled: false,
      });
      
      setCoursesCount(0);
      setAssignmentsCount(0);

      toast({
        title: 'Disconnected',
        description: 'Google Classroom has been disconnected.',
      });
    } catch (error) {
      console.error('Error disconnecting Google Classroom:', error);
      toast({
        title: 'Error',
        description: 'Failed to disconnect Google Classroom.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSync = async () => {
    if (!authStatus.isConnected) return;

    setIsSyncing(true);
    try {
      // Call the sync function
      const { data, error } = await supabase.functions.invoke('sync-google-classroom', {
        body: { userId: user?.id }
      });

      if (error) throw error;

      const syncedCount = data?.syncedAssignments || 0;
      
      // Update last sync date
      await supabase
        .from('user_settings')
        .update({
          last_sync_date: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user?.id);

      setAuthStatus(prev => ({
        ...prev,
        lastSync: new Date().toISOString(),
      }));

      toast({
        title: 'Sync Complete!',
        description: `Successfully synced ${syncedCount} assignments to your calendar.`,
      });
    } catch (error) {
      console.error('Error syncing assignments:', error);
      toast({
        title: 'Sync Failed',
        description: 'Failed to sync assignments. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const toggleAutoSync = async (enabled: boolean) => {
    try {
      await supabase
        .from('user_settings')
        .update({
          auto_sync_enabled: enabled,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user?.id);

      setAuthStatus(prev => ({ ...prev, autoSyncEnabled: enabled }));

      toast({
        title: enabled ? 'Auto-sync Enabled' : 'Auto-sync Disabled',
        description: enabled 
          ? 'Assignments will be automatically synced to your calendar.'
          : 'You will need to manually sync assignments.',
      });
    } catch (error) {
      console.error('Error updating auto-sync setting:', error);
      toast({
        title: 'Error',
        description: 'Failed to update auto-sync setting.',
        variant: 'destructive',
      });
    }
  };

  return (
    <Card className="p-6 shadow-soft">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <School className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Google Classroom</h3>
              <p className="text-sm text-muted-foreground">Sync your assignments automatically</p>
            </div>
          </div>
          <Badge variant={authStatus.isConnected ? 'default' : 'secondary'}>
            {authStatus.isConnected ? 'Connected' : 'Disconnected'}
          </Badge>
        </div>

        <Separator />

        {/* Connection Status */}
        {authStatus.isConnected ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Connected to Google Classroom</span>
              {authStatus.email && <span className="text-muted-foreground">({authStatus.email})</span>}
            </div>
            
            {/* Data Counts */}
            {(coursesCount > 0 || assignmentsCount > 0) && (
              <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold">{coursesCount}</div>
                  <div className="text-sm text-muted-foreground">Courses</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{assignmentsCount}</div>
                  <div className="text-sm text-muted-foreground">Assignments</div>
                </div>
              </div>
            )}

            {/* Last Sync */}
            {authStatus.lastSync && (
              <div className="text-sm text-muted-foreground">
                Last synced: {new Date(authStatus.lastSync).toLocaleString()}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <AlertCircle className="h-4 w-4" />
              <span>Not connected to Google Classroom</span>
            </div>
            
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-start gap-3">
                <ExternalLink className="h-5 w-5 text-blue-600 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium mb-1">Connect to Google Classroom to:</p>
                  <ul className="space-y-1 text-blue-700">
                    <li>• Automatically sync assignments to your calendar</li>
                    <li>• Get notifications for upcoming deadlines</li>
                    <li>• Track your progress across all courses</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-3">
          {authStatus.isConnected ? (
            <>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-sync">Auto-sync</Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically sync new assignments
                  </p>
                </div>
                <Switch
                  id="auto-sync"
                  checked={authStatus.autoSyncEnabled}
                  onCheckedChange={toggleAutoSync}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleSync}
                  disabled={isSyncing}
                  className="flex-1"
                >
                  {isSyncing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Syncing...
                    </>
                  ) : (
                    <>
                      <Sync className="h-4 w-4 mr-2" />
                      Sync Now
                    </>
                  )}
                </Button>
                
                <Button
                  variant="outline"
                  onClick={handleDisconnect}
                  disabled={isLoading}
                >
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </>
          ) : (
            <Button
              onClick={handleGoogleAuth}
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <School className="h-4 w-4 mr-2" />
                  Connect Google Classroom
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
};

export default GoogleAuth;