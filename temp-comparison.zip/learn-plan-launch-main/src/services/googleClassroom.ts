import { 
  GoogleClassroomAssignment, 
  GoogleClassroomCourse, 
  GoogleAuthResponse,
  GoogleCalendarEvent 
} from '@/types/google';

export class GoogleClassroomService {
  private static instance: GoogleClassroomService;
  private accessToken: string | null = null;
  private refreshToken: string | null = null;
  private tokenExpiry: number = 0;

  static getInstance(): GoogleClassroomService {
    if (!GoogleClassroomService.instance) {
      GoogleClassroomService.instance = new GoogleClassroomService();
    }
    return GoogleClassroomService.instance;
  }

  // Initialize with stored tokens
  initialize(accessToken: string, refreshToken?: string, expiresIn?: number): void {
    this.accessToken = accessToken;
    this.refreshToken = refreshToken || null;
    this.tokenExpiry = Date.now() + (expiresIn ? expiresIn * 1000 : 3600 * 1000);
  }

  // Check if token is expired and refresh if needed
  private async ensureValidToken(): Promise<string> {
    if (!this.accessToken) {
      throw new Error('No access token available. Please authenticate first.');
    }

    if (Date.now() >= this.tokenExpiry - 60000) { // Refresh 1 minute before expiry
      if (this.refreshToken) {
        await this.refreshAccessToken();
      } else {
        throw new Error('Access token expired and no refresh token available.');
      }
    }

    return this.accessToken;
  }

  // Refresh access token
  private async refreshAccessToken(): Promise<void> {
    if (!this.refreshToken) {
      throw new Error('No refresh token available.');
    }

    try {
      const response = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          client_id: import.meta.env.VITE_GOOGLE_CLIENT_ID,
          client_secret: import.meta.env.VITE_GOOGLE_CLIENT_SECRET,
          refresh_token: this.refreshToken,
          grant_type: 'refresh_token',
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to refresh token');
      }

      const data: GoogleAuthResponse = await response.json();
      this.accessToken = data.access_token;
      this.tokenExpiry = Date.now() + (data.expires_in * 1000);
    } catch (error) {
      console.error('Error refreshing token:', error);
      throw error;
    }
  }

  // Make authenticated API requests
  private async makeRequest(url: string, options: RequestInit = {}): Promise<any> {
    const token = await this.ensureValidToken();
    
    const response = await fetch(url, {
      ...options,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        // Try to refresh token once more
        await this.refreshAccessToken();
        const newToken = await this.ensureValidToken();
        
        const retryResponse = await fetch(url, {
          ...options,
          headers: {
            'Authorization': `Bearer ${newToken}`,
            'Content-Type': 'application/json',
            ...options.headers,
          },
        });

        if (!retryResponse.ok) {
          throw new Error(`API request failed: ${retryResponse.statusText}`);
        }

        return retryResponse.json();
      }
      throw new Error(`API request failed: ${response.statusText}`);
    }

    return response.json();
  }

  // Get user's Google Classroom courses
  async getCourses(): Promise<GoogleClassroomCourse[]> {
    try {
      const response = await this.makeRequest(
        'https://classroom.googleapis.com/v1/courses?courseStates=ACTIVE'
      );
      
      return response.courses || [];
    } catch (error) {
      console.error('Error fetching courses:', error);
      throw error;
    }
  }

  // Get assignments for a specific course
  async getCourseAssignments(courseId: string): Promise<GoogleClassroomAssignment[]> {
    try {
      const response = await this.makeRequest(
        `https://classroom.googleapis.com/v1/courses/${courseId}/courseWork`
      );
      
      const assignments = response.courseWork || [];
      
      // Enrich assignments with course name
      const course = await this.getCourseById(courseId);
      return assignments.map((assignment: any) => ({
        ...assignment,
        courseName: course?.name || 'Unknown Course',
        courseId: course?.id || courseId,
      }));
    } catch (error) {
      console.error('Error fetching assignments:', error);
      throw error;
    }
  }

  // Get all assignments from all active courses
  async getAllAssignments(): Promise<GoogleClassroomAssignment[]> {
    try {
      const courses = await this.getCourses();
      const allAssignments: GoogleClassroomAssignment[] = [];
      
      for (const course of courses) {
        try {
          const assignments = await this.getCourseAssignments(course.id);
          allAssignments.push(...assignments);
        } catch (error) {
          console.error(`Error fetching assignments for course ${course.name}:`, error);
          // Continue with other courses even if one fails
        }
      }
      
      // Sort by due date
      return allAssignments.sort((a, b) => {
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        
        const aDate = new Date(a.dueDate.year, a.dueDate.month - 1, a.dueDate.day);
        const bDate = new Date(b.dueDate.year, b.dueDate.month - 1, b.dueDate.day);
        
        return aDate.getTime() - bDate.getTime();
      });
    } catch (error) {
      console.error('Error fetching all assignments:', error);
      throw error;
    }
  }

  // Get course by ID
  private async getCourseById(courseId: string): Promise<GoogleClassroomCourse | null> {
    try {
      const response = await this.makeRequest(
        `https://classroom.googleapis.com/v1/courses/${courseId}`
      );
      return response;
    } catch (error) {
      console.error('Error fetching course:', error);
      return null;
    }
  }

  // Convert Google Classroom assignment to calendar event
  convertAssignmentToCalendarEvent(assignment: GoogleClassroomAssignment): GoogleCalendarEvent {
    const summary = `[Assignment] ${assignment.title}`;
    const description = this.createAssignmentDescription(assignment);
    
    // Calculate due date and time
    let startDateTime: string;
    let endDateTime: string;
    
    if (assignment.dueDate) {
      const dueDate = new Date(assignment.dueDate.year, assignment.dueDate.month - 1, assignment.dueDate.day);
      
      if (assignment.dueTime) {
        dueDate.setHours(assignment.dueTime.hours, assignment.dueTime.minutes, 0, 0);
        endDateTime = dueDate.toISOString();
        
        // Start 1 hour before due time
        const startDate = new Date(dueDate.getTime() - 60 * 60 * 1000);
        startDateTime = startDate.toISOString();
      } else {
        // If no time specified, make it an all-day event
        const nextDay = new Date(dueDate.getTime() + 24 * 60 * 60 * 1000);
        startDateTime = dueDate.toISOString().split('T')[0];
        endDateTime = nextDay.toISOString().split('T')[0];
      }
    } else {
      // If no due date, schedule for tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      startDateTime = tomorrow.toISOString().split('T')[0];
      endDateTime = tomorrow.toISOString().split('T')[0];
    }
    
    return {
      summary,
      description,
      start: assignment.dueTime ? {
        dateTime: startDateTime,
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      } : {
        date: startDateTime,
      },
      end: assignment.dueTime ? {
        dateTime: endDateTime,
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      } : {
        date: endDateTime,
      },
      colorId: '11', // Red color for assignments
      reminders: {
        useDefault: false,
        overrides: [
          { method: 'popup' as const, minutes: 1440 }, // 1 day before
          { method: 'popup' as const, minutes: 60 }, // 1 hour before
        ],
      },
      extendedProperties: {
        private: {
          source: 'google-classroom',
          assignmentId: assignment.id,
          courseId: assignment.courseId,
        },
      },
    };
  }

  // Create assignment description with links and materials
  private createAssignmentDescription(assignment: GoogleClassroomAssignment): string {
    let description = `Course: ${assignment.courseName}\n`;
    
    if (assignment.description) {
      description += `\n${assignment.description}\n`;
    }
    
    if (assignment.maxPoints) {
      description += `\nPoints: ${assignment.maxPoints}\n`;
    }
    
    if (assignment.link) {
      description += `\n📚 View Assignment: ${assignment.link}\n`;
    }
    
    if (assignment.materials && assignment.materials.length > 0) {
      description += '\n📎 Materials:\n';
      assignment.materials.forEach((material, index) => {
        if (material.driveFile) {
          description += `• ${material.driveFile.title}: ${material.driveFile.alternateLink}\n`;
        } else if (material.link) {
          description += `• ${material.link.title}: ${material.link.url}\n`;
        } else if (material.youtubeVideo) {
          description += `• 📺 ${material.youtubeVideo.title}: ${material.youtubeVideo.alternateLink}\n`;
        } else if (material.form) {
          description += `• 📝 ${material.form.title}: https://docs.google.com/forms/d/${material.form.id}/view\n`;
        }
      });
    }
    
    description += `\n---\nSynced from Google Classroom`;
    
    return description;
  }

  // Add assignment to Google Calendar
  async addAssignmentToCalendar(assignment: GoogleClassroomAssignment): Promise<GoogleCalendarEvent> {
    try {
      const calendarEvent = this.convertAssignmentToCalendarEvent(assignment);
      
      const response = await this.makeRequest('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        body: JSON.stringify(calendarEvent),
      });
      
      return response;
    } catch (error) {
      console.error('Error adding assignment to calendar:', error);
      throw error;
    }
  }

  // Batch add assignments to calendar
  async addAssignmentsToCalendar(assignments: GoogleClassroomAssignment[]): Promise<GoogleCalendarEvent[]> {
    const results: GoogleCalendarEvent[] = [];
    
    for (const assignment of assignments) {
      try {
        const event = await this.addAssignmentToCalendar(assignment);
        results.push(event);
        
        // Small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        console.error(`Failed to add assignment "${assignment.title}" to calendar:`, error);
        // Continue with other assignments
      }
    }
    
    return results;
  }

  // Check if assignment is already in calendar
  async isAssignmentInCalendar(assignmentId: string): Promise<boolean> {
    try {
      const response = await this.makeRequest(
        `https://www.googleapis.com/calendar/v3/calendars/primary/events?q=google-classroom:${assignmentId}`
      );
      
      return response.items && response.items.length > 0;
    } catch (error) {
      console.error('Error checking calendar for assignment:', error);
      return false;
    }
  }

  // Get current authentication status
  isAuthenticated(): boolean {
    return this.accessToken !== null && Date.now() < this.tokenExpiry;
  }

  // Clear authentication tokens
  clearAuth(): void {
    this.accessToken = null;
    this.refreshToken = null;
    this.tokenExpiry = 0;
  }

  // Get stored tokens
  getTokens(): { accessToken: string | null; refreshToken: string | null } {
    return {
      accessToken: this.accessToken,
      refreshToken: this.refreshToken,
    };
  }
}

export default GoogleClassroomService.getInstance();