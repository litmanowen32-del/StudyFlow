import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Home, ArrowLeft, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  const suggestions = [
    { path: "/", label: "Dashboard", icon: Home },
    { path: "/calendar", label: "Calendar", icon: Home },
    { path: "/tasks", label: "Tasks", icon: Home },
    { path: "/focus", label: "Focus Timer", icon: Home },
  ];

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="max-w-md w-full">
        <Card className="p-8 text-center shadow-soft">
          {/* Error Icon and Code */}
          <div className="mb-6">
            <div className="relative inline-block">
              <div className="text-8xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                404
              </div>
              <div className="absolute -top-2 -right-2">
                <div className="h-4 w-4 bg-destructive rounded-full animate-pulse"></div>
              </div>
            </div>
          </div>

          {/* Error Message */}
          <div className="mb-8">
            <h1 className="mb-3 text-2xl font-semibold text-foreground">
              Page Not Found
            </h1>
            <p className="text-muted-foreground leading-relaxed">
              Oops! The page you're looking for doesn't exist or has been moved. 
              Let's get you back on track.
            </p>
            <div className="mt-4 text-xs text-muted-foreground bg-muted/50 p-2 rounded">
              <code>Path: {location.pathname}</code>
            </div>
          </div>

          {/* Navigation Options */}
          <div className="space-y-4">
            {/* Primary Action */}
            <Link to="/">
              <Button className="w-full bg-gradient-primary shadow-glow hover:shadow-accent-glow transition-all">
                <Home className="h-4 w-4 mr-2" />
                Return to Dashboard
              </Button>
            </Link>

            {/* Secondary Action */}
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => window.history.back()}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Go Back
            </Button>
          </div>

          {/* Helpful Suggestions */}
          <div className="mt-8 pt-6 border-t border-border">
            <div className="flex items-center justify-center mb-4 text-sm text-muted-foreground">
              <Search className="h-4 w-4 mr-2" />
              <span>Maybe you're looking for:</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {suggestions.map((suggestion, index) => (
                <Link key={index} to={suggestion.path}>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="w-full h-auto p-2 text-xs"
                  >
                    {suggestion.label}
                  </Button>
                </Link>
              ))}
            </div>
          </div>
        </Card>

        {/* Help Footer */}
        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            Need help?{" "}
            <Link 
              to="/about" 
              className="text-primary hover:text-primary/80 underline"
            >
              Contact Support
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
