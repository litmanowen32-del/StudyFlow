import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

const GoogleCallback = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const { user } = useAuth();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('Connecting to Google Classroom...');

  useEffect(() => {
    handleGoogleCallback();
  }, []);

  const handleGoogleCallback = async () => {
    const code = searchParams.get('code');
    const error = searchParams.get('error');

    if (error) {
      setStatus('error');
      setMessage('Authentication failed. Please try again.');
      
      // Send error message to parent window
      window.opener?.postMessage({
        type: 'GOOGLE_AUTH_ERROR',
        error: error
      }, window.location.origin);
      
      setTimeout(() => {
        window.close();
      }, 2000);
      return;
    }

    if (!code) {
      setStatus('error');
      setMessage('No authorization code received.');
      
      window.opener?.postMessage({
        type: 'GOOGLE_AUTH_ERROR',
        error: 'No authorization code received'
      }, window.location.origin);
      
      setTimeout(() => {
        window.close();
      }, 2000);
      return;
    }

    try {
      // Get user info from the token
      const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: {
          'Authorization': `Bearer ${code}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to get user info from Google');
      }

      const userInfo = await response.json();

      // Send success message to parent window
      window.opener?.postMessage({
        type: 'GOOGLE_AUTH_SUCCESS',
        code: code,
        email: userInfo.email,
        name: userInfo.name
      }, window.location.origin);

      setStatus('success');
      setMessage('Successfully connected to Google Classroom!');

      // Close window after a short delay
      setTimeout(() => {
        window.close();
      }, 1500);

    } catch (error) {
      console.error('Error handling Google callback:', error);
      setStatus('error');
      setMessage('Failed to connect to Google Classroom. Please try again.');
      
      window.opener?.postMessage({
        type: 'GOOGLE_AUTH_ERROR',
        error: error instanceof Error ? error.message : 'Unknown error'
      }, window.location.origin);
      
      setTimeout(() => {
        window.close();
      }, 2000);
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'loading':
        return <Loader2 className="h-8 w-8 animate-spin text-blue-600" />;
      case 'success':
        return <CheckCircle className="h-8 w-8 text-green-600" />;
      case 'error':
        return <AlertCircle className="h-8 w-8 text-red-600" />;
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'loading':
        return 'text-blue-600';
      case 'success':
        return 'text-green-600';
      case 'error':
        return 'text-red-600';
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <Card className="w-full max-w-md p-8 shadow-soft">
        <div className="text-center space-y-6">
          {/* Status Icon */}
          <div className="flex justify-center">
            {getStatusIcon()}
          </div>

          {/* Status Message */}
          <div className="space-y-2">
            <h2 className={`text-xl font-semibold ${getStatusColor()}`}>
              {status === 'loading' && 'Connecting...'}
              {status === 'success' && 'Connected!'}
              {status === 'error' && 'Connection Failed'}
            </h2>
            <p className="text-muted-foreground">
              {message}
            </p>
          </div>

          {/* Instructions */}
          <div className="text-sm text-muted-foreground">
            {status === 'loading' && (
              <p>Please wait while we connect your Google Classroom account...</p>
            )}
            {status === 'success' && (
              <p>This window will close automatically.</p>
            )}
            {status === 'error' && (
              <p>This window will close automatically. Please try again.</p>
            )}
          </div>

          {/* Manual close button (fallback) */}
          {status !== 'loading' && (
            <button
              onClick={() => window.close()}
              className="text-sm text-primary hover:underline"
            >
              Close Window
            </button>
          )}
        </div>
      </Card>
    </div>
  );
};

export default GoogleCallback;