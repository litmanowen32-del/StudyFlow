import { useState, useEffect } from "react";
import { Plus, Filter, Sparkles, Trash2, Loader2, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Task, CreateTaskInput, UpdateTaskInput, LoadingState } from "@/types";

interface TaskFormData {
  title: string;
  description: string;
  priority: Task['priority'];
  subject: string;
  due_date: string;
}

const Tasks = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState<LoadingState>({ isLoading: false });
  const [open, setOpen] = useState(false);
  const [newTask, setNewTask] = useState<TaskFormData>({
    title: "",
    description: "",
    priority: "medium",
    subject: "",
    due_date: "",
  });

  useEffect(() => {
    if (user) fetchTasks();
  }, [user]);

  const fetchTasks = async () => {
    if (!user) return;
    
    setLoading({ isLoading: true });
    try {
      const { data, error } = await supabase
        .from("tasks")
        .select("*")
        .eq("user_id", user.id)
        .order("due_date", { ascending: true });
      
      if (error) {
        throw new Error(error.message);
      }
      
      setTasks(data as Task[] || []);
    } catch (error) {
      setLoading({ 
        isLoading: false, 
        error: { 
          code: 'FETCH_TASKS_ERROR', 
          message: error instanceof Error ? error.message : 'Failed to fetch tasks' 
        } 
      });
      toast({ 
        title: "Error", 
        description: "Failed to load tasks", 
        variant: "destructive" 
      });
    } finally {
      setLoading({ isLoading: false });
    }
  };

  const createTask = async () => {
    if (!newTask.title.trim()) {
      toast({ title: "Please enter a task title", variant: "destructive" });
      return;
    }

    if (!user) {
      toast({ title: "User not authenticated", variant: "destructive" });
      return;
    }

    setLoading({ isLoading: true });
    try {
      const taskData: CreateTaskInput = {
        title: newTask.title.trim(),
        description: newTask.description.trim() || undefined,
        priority: newTask.priority as Task['priority'],
        due_date: newTask.due_date || undefined,
        category: newTask.subject.trim() || undefined,
        tags: []
      };

      const { error } = await supabase.from("tasks").insert({
        user_id: user.id,
        ...taskData,
        status: 'todo',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });

      if (error) {
        throw new Error(error.message);
      }

      toast({ 
        title: "Task created!", 
        description: "Visit the Calendar to schedule it with AI"
      });
      
      // Reset form
      setNewTask({ title: "", description: "", priority: "medium", subject: "", due_date: "" });
      setOpen(false);
      await fetchTasks();
    } catch (error) {
      toast({ 
        title: "Error", 
        description: error instanceof Error ? error.message : "Failed to create task",
        variant: "destructive" 
      });
    } finally {
      setLoading({ isLoading: false });
    }
  };

  const toggleTask = async (taskId: string, completed: boolean) => {
    if (!user) return;
    
    setLoading({ isLoading: true });
    try {
      const updateData: UpdateTaskInput = {
        status: !completed ? 'completed' : 'todo',
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from("tasks")
        .update(updateData)
        .eq("id", taskId)
        .eq("user_id", user.id);

      if (error) {
        throw new Error(error.message);
      }

      toast({ 
        title: completed ? "Task reopened" : "Task completed!",
        description: !completed ? "Great job! Keep up the momentum." : undefined
      });
      
      await fetchTasks();
    } catch (error) {
      toast({ 
        title: "Error", 
        description: error instanceof Error ? error.message : "Failed to update task",
        variant: "destructive" 
      });
    } finally {
      setLoading({ isLoading: false });
    }
  };

  const getDaysUntil = (dueDate: string) => {
    if (!dueDate) return "No due date";
    const days = Math.ceil((new Date(dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    if (days < 0) return "Overdue";
    if (days === 0) return "Due today";
    if (days === 1) return "Due tomorrow";
    return `Due in ${days} days`;
  };

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case "urgent":
      case "high": return "destructive";
      case "medium": return "warning";
      case "low": return "secondary";
      default: return "default";
    }
  };

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="mb-8 flex items-center justify-between animate-fade-in">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-3">
            <Sparkles className="h-4 w-4" />
            <span>Task Management</span>
          </div>
          <h1 className="text-4xl font-bold mb-2 bg-gradient-primary bg-clip-text text-transparent">
            Tasks
          </h1>
          <p className="text-lg text-muted-foreground">
            Manage and prioritize your assignments
          </p>
        </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-primary shadow-glow">
                <Plus className="h-4 w-4" />
                Add Task
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Task Title *</Label>
                  <Input
                    id="title"
                    value={newTask.title}
                    onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                    placeholder="Complete assignment"
                  />
                </div>
                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select
                    value={newTask.priority}
                    onValueChange={(value) => setNewTask({ ...newTask, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="subject">Subject</Label>
                  <Input
                    id="subject"
                    value={newTask.subject}
                    onChange={(e) => setNewTask({ ...newTask, subject: e.target.value })}
                    placeholder="Mathematics"
                  />
                </div>
                <div>
                  <Label htmlFor="due-date">Due Date</Label>
                  <Input
                    id="due-date"
                    type="datetime-local"
                    value={newTask.due_date}
                    onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newTask.description}
                    onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                    placeholder="Additional details..."
                  />
                </div>
                <Button onClick={createTask} className="w-full">Create Task</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {loading.isLoading && (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2 text-muted-foreground">Loading tasks...</span>
          </div>
        )}

        {!loading.isLoading && (
          <div className="grid gap-6 lg:grid-cols-2">
            <div>
              <h2 className="mb-4 text-xl font-semibold text-foreground">
                Active Tasks ({tasks.filter(t => t.status !== 'completed').length})
              </h2>
              <div className="space-y-3">
                {tasks.filter(t => t.status !== 'completed').length === 0 ? (
                  <Card className="p-8 text-center">
                    <div className="text-muted-foreground">
                      <Plus className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No active tasks</p>
                      <p className="text-sm mt-2">Create your first task to get started!</p>
                    </div>
                  </Card>
                ) : (
                  tasks.filter(t => t.status !== 'completed').map((task) => (
                <Card key={task.id} className="p-4 shadow-soft transition-all hover:shadow-glow">
                  <div className="flex items-start gap-3">
                    <Checkbox 
                      className="mt-1" 
                      checked={task.status === 'completed'}
                      onCheckedChange={() => toggleTask(task.id, task.status === 'completed')}
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-medium text-card-foreground">{task.title}</h3>
                        <div className="flex items-center gap-2">
                          <Badge variant={getPriorityColor(task.priority)}>
                            {task.priority}
                          </Badge>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-destructive hover:text-destructive"
                            onClick={async () => {
                              if (!user) return;
                              
                              try {
                                const { error } = await supabase
                                  .from("tasks") 
                                  .delete() 
                                  .eq("id", task.id)
                                  .eq("user_id", user.id);
                                
                                if (error) throw new Error(error.message);
                                
                                toast({ title: "Task deleted successfully" });
                                await fetchTasks();
                              } catch (error) {
                                toast({ 
                                  title: "Error", 
                                  description: "Failed to delete task",
                                  variant: "destructive" 
                                });
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      {task.description && (
                        <p className="mt-1 text-sm text-muted-foreground">{task.description}</p>
                      )}
                      <div className="mt-2 flex items-center gap-4 text-sm text-muted-foreground">
                        {task.category && <span>{task.category}</span>}
                        {task.category && task.due_date && <span>•</span>}
                        {task.due_date && <span>{getDaysUntil(task.due_date)}</span>}
                        {task.estimated_duration && (
                          <>
                            {(task.category || task.due_date) && <span>•</span>}
                            <span>~{task.estimated_duration}min</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
                  ))
                )}
              </div>
            </div>

            <div>
              <h2 className="mb-4 text-xl font-semibold text-foreground">
                Completed Tasks ({tasks.filter(t => t.status === 'completed').length})
              </h2>
              <div className="space-y-3">
                {tasks.filter(t => t.status === 'completed').length === 0 ? (
                  <Card className="p-8 text-center opacity-60">
                    <div className="text-muted-foreground">
                      <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No completed tasks yet</p>
                      <p className="text-sm mt-2">Keep working on your active tasks!</p>
                    </div>
                  </Card>
                ) : (
                  tasks.filter(t => t.status === 'completed').map((task) => (
                <Card key={task.id} className="p-4 opacity-60 shadow-soft">
                  <div className="flex items-start gap-3">
                    <Checkbox 
                      checked 
                      className="mt-1" 
                      onCheckedChange={() => toggleTask(task.id, task.status === 'completed')}
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-card-foreground line-through">{task.title}</h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={async () => {
                            if (!user) return;
                            
                            try {
                              const { error } = await supabase
                                .from("tasks") 
                                .delete() 
                                .eq("id", task.id)
                                .eq("user_id", user.id);
                              
                              if (error) throw new Error(error.message);
                              
                              toast({ title: "Task deleted successfully" });
                              await fetchTasks();
                            } catch (error) {
                              toast({ 
                                title: "Error", 
                                description: "Failed to delete task",
                                variant: "destructive" 
                              });
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="mt-2 flex items-center gap-4 text-sm text-muted-foreground">
                        {task.category && <span>{task.category}</span>}
                        {task.due_date && (
                          <span>Completed {new Date(task.updated_at).toLocaleDateString()}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
  );
};

export default Tasks;
