import { useState, useEffect } from "react";
import { Sparkles, Calendar as CalendarIcon } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { HourlyCalendar } from "@/components/HourlyCalendar";
import { MonthlyCalendar } from "@/components/MonthlyCalendar";
import { PendingTasks } from "@/components/PendingTasks";
import GoogleAuth from "@/components/GoogleAuth";
import GoogleCalendarEvents from "@/components/GoogleCalendarEvents";

const Calendar = () => {
  const [view, setView] = useState<"hourly" | "monthly">("hourly");
  const [googleEventsCount, setGoogleEventsCount] = useState(0);

  useEffect(() => {
    // Load Google Classroom events count
    loadGoogleEventsCount();
  }, []);

  const loadGoogleEventsCount = async () => {
    try {
      // This would be implemented to count Google Classroom events
      // For now, we'll use a placeholder
      setGoogleEventsCount(0);
    } catch (error) {
      console.error('Error loading Google events count:', error);
    }
  };

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="mb-8 animate-fade-in">
        <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
          <Sparkles className="h-4 w-4" />
          <span>Smart Scheduling with AI</span>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-3 bg-gradient-primary bg-clip-text text-transparent">
              Calendar
            </h1>
            <p className="text-lg text-muted-foreground">
              Drag, resize, and schedule with AI-powered time suggestions
            </p>
          </div>
          {googleEventsCount > 0 && (
            <Badge variant="secondary" className="text-sm">
              <CalendarIcon className="h-3 w-3 mr-1" />
              {googleEventsCount} Classroom assignments
            </Badge>
          )}
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        {/* Google Classroom Integration */}
        <div className="lg:col-span-1">
          <div className="space-y-6">
            <GoogleAuth />
            <GoogleCalendarEvents />
          </div>
        </div>

        {/* Main Calendar Content */}
        <div className="lg:col-span-2">
          <PendingTasks />
        </div>
      </div>

      <Tabs value={view} onValueChange={(v) => setView(v as "hourly" | "monthly")} className="space-y-4">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="hourly">Hourly View</TabsTrigger>
          <TabsTrigger value="monthly">Monthly View</TabsTrigger>
        </TabsList>

        <TabsContent value="hourly">
          <HourlyCalendar />
        </TabsContent>

        <TabsContent value="monthly">
          <MonthlyCalendar />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Calendar;
