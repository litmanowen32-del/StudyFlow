import { supabase } from '@/integrations/supabase/client';
import { Task, Habit, Goal, Routine, FocusSession, CalendarEvent, ApiResponse, PaginatedResponse } from '@/types';

// Generic API wrapper for consistent error handling
class ApiClient {
  private handleApiError = (error: any, customMessage?: string) => {
    const message = customMessage || error?.message || 'An unexpected error occurred';
    console.error('API Error:', error);
    throw new Error(message);
  };

  // Tasks API
  async getTasks(userId: string): Promise<Task[]> {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', userId)
        .order('due_date', { ascending: true });

      if (error) this.handleApiError(error, 'Failed to fetch tasks');
      return data as Task[] || [];
    } catch (error) {
      this.handleApiError(error, 'Failed to fetch tasks');
      return [];
    }
  }

  async createTask(task: Omit<Task, 'id' | 'created_at' | 'updated_at'>): Promise<Task> {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .insert({
          ...task,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) this.handleApiError(error, 'Failed to create task');
      return data as Task;
    } catch (error) {
      this.handleApiError(error, 'Failed to create task');
      throw error;
    }
  }

  async updateTask(id: string, updates: Partial<Task>): Promise<Task> {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select()
        .single();

      if (error) this.handleApiError(error, 'Failed to update task');
      return data as Task;
    } catch (error) {
      this.handleApiError(error, 'Failed to update task');
      throw error;
    }
  }

  async deleteTask(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', id);

      if (error) this.handleApiError(error, 'Failed to delete task');
    } catch (error) {
      this.handleApiError(error, 'Failed to delete task');
    }
  }

  // Habits API
  async getHabits(userId: string): Promise<Habit[]> {
    try {
      const { data, error } = await supabase
        .from('habits')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) this.handleApiError(error, 'Failed to fetch habits');
      return data as Habit[] || [];
    } catch (error) {
      this.handleApiError(error, 'Failed to fetch habits');
      return [];
    }
  }

  async createHabit(habit: Omit<Habit, 'id' | 'created_at' | 'updated_at'>): Promise<Habit> {
    try {
      const { data, error } = await supabase
        .from('habits')
        .insert({
          ...habit,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) this.handleApiError(error, 'Failed to create habit');
      return data as Habit;
    } catch (error) {
      this.handleApiError(error, 'Failed to create habit');
      throw error;
    }
  }

  async updateHabit(id: string, updates: Partial<Habit>): Promise<Habit> {
    try {
      const { data, error } = await supabase
        .from('habits')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select()
        .single();

      if (error) this.handleApiError(error, 'Failed to update habit');
      return data as Habit;
    } catch (error) {
      this.handleApiError(error, 'Failed to update habit');
      throw error;
    }
  }

  async deleteHabit(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('habits')
        .delete()
        .eq('id', id);

      if (error) this.handleApiError(error, 'Failed to delete habit');
    } catch (error) {
      this.handleApiError(error, 'Failed to delete habit');
    }
  }

  // Goals API
  async getGoals(userId: string): Promise<Goal[]> {
    try {
      const { data, error } = await supabase
        .from('goals')
        .select('*')
        .eq('user_id', userId)
        .order('target_date', { ascending: true });

      if (error) this.handleApiError(error, 'Failed to fetch goals');
      return data as Goal[] || [];
    } catch (error) {
      this.handleApiError(error, 'Failed to fetch goals');
      return [];
    }
  }

  async createGoal(goal: Omit<Goal, 'id' | 'created_at' | 'updated_at'>): Promise<Goal> {
    try {
      const { data, error } = await supabase
        .from('goals')
        .insert({
          ...goal,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) this.handleApiError(error, 'Failed to create goal');
      return data as Goal;
    } catch (error) {
      this.handleApiError(error, 'Failed to create goal');
      throw error;
    }
  }

  // Analytics API
  async getAnalytics(userId: string): Promise<any> {
    try {
      // This would typically call a Supabase Edge Function
      // For now, we'll implement basic analytics
      const [tasks, habits, goals] = await Promise.all([
        this.getTasks(userId),
        this.getHabits(userId),
        this.getGoals(userId)
      ]);

      const completedTasks = tasks.filter(t => t.status === 'completed').length;
      const activeHabits = habits.filter(h => h.is_active).length;
      const activeGoals = goals.filter(g => g.status === 'active').length;

      return {
        total_study_hours: 0, // Calculate from focus sessions
        tasks_completed: completedTasks,
        goals_achieved: goals.filter(g => g.status === 'completed').length,
        productivity_score: Math.round((completedTasks / Math.max(tasks.length, 1)) * 100),
        focus_sessions_completed: 0, // Calculate from focus sessions
        average_focus_duration: 0,
        habit_completion_rate: Math.round((activeHabits / Math.max(habits.length, 1)) * 100),
        weekly_progress: []
      };
    } catch (error) {
      this.handleApiError(error, 'Failed to fetch analytics');
      return null;
    }
  }

  // Focus Sessions API
  async createFocusSession(session: Omit<FocusSession, 'id'>): Promise<FocusSession> {
    try {
      const { data, error } = await supabase
        .from('focus_sessions')
        .insert(session)
        .select()
        .single();

      if (error) this.handleApiError(error, 'Failed to create focus session');
      return data as FocusSession;
    } catch (error) {
      this.handleApiError(error, 'Failed to create focus session');
      throw error;
    }
  }

  async getFocusSessions(userId: string, limit = 50): Promise<FocusSession[]> {
    try {
      const { data, error } = await supabase
        .from('focus_sessions')
        .select('*')
        .eq('user_id', userId)
        .order('start_time', { ascending: false })
        .limit(limit);

      if (error) this.handleApiError(error, 'Failed to fetch focus sessions');
      return data as FocusSession[] || [];
    } catch (error) {
      this.handleApiError(error, 'Failed to fetch focus sessions');
      return [];
    }
  }

  // Calendar Events API
  async getCalendarEvents(userId: string): Promise<CalendarEvent[]> {
    try {
      const { data, error } = await supabase
        .from('calendar_events')
        .select('*')
        .eq('user_id', userId)
        .order('start_time', { ascending: true });

      if (error) this.handleApiError(error, 'Failed to fetch calendar events');
      return data as CalendarEvent[] || [];
    } catch (error) {
      this.handleApiError(error, 'Failed to fetch calendar events');
      return [];
    }
  }

  // Edge Functions API
  async callEdgeFunction<T>(
    functionName: string,
    payload: any,
    options?: RequestInit
  ): Promise<T> {
    try {
      const { data, error } = await supabase.functions.invoke(functionName, {
        body: payload,
        ...options
      });

      if (error) this.handleApiError(error, `Failed to call ${functionName}`);
      return data as T;
    } catch (error) {
      this.handleApiError(error, `Failed to call ${functionName}`);
      throw error;
    }
  }

  // AI Study Planner
  async generateStudyPlan(userId: string, preferences: any): Promise<any> {
    return this.callEdgeFunction('ai-study-planner', { userId, preferences });
  }

  // Task Duration Estimator
  async estimateTaskDuration(taskInfo: any): Promise<any> {
    return this.callEdgeFunction('estimate-task-duration', taskInfo);
  }

  // Time Slot Suggestions
  async suggestTimeSlots(userId: string, requirements: any): Promise<any> {
    return this.callEdgeFunction('suggest-time-slots', { userId, requirements });
  }

  // Study Assistant
  async askStudyAssistant(userId: string, question: string): Promise<any> {
    return this.callEdgeFunction('study-assistant', { userId, question });
  }
}

// Export singleton instance
export const apiClient = new ApiClient();

// Export convenience hooks
export const useApi = () => ({
  tasks: {
    getAll: (userId: string) => apiClient.getTasks(userId),
    create: (task: Omit<Task, 'id' | 'created_at' | 'updated_at'>) => apiClient.createTask(task),
    update: (id: string, updates: Partial<Task>) => apiClient.updateTask(id, updates),
    delete: (id: string) => apiClient.deleteTask(id),
  },
  habits: {
    getAll: (userId: string) => apiClient.getHabits(userId),
    create: (habit: Omit<Habit, 'id' | 'created_at' | 'updated_at'>) => apiClient.createHabit(habit),
    update: (id: string, updates: Partial<Habit>) => apiClient.updateHabit(id, updates),
    delete: (id: string) => apiClient.deleteHabit(id),
  },
  goals: {
    getAll: (userId: string) => apiClient.getGoals(userId),
    create: (goal: Omit<Goal, 'id' | 'created_at' | 'updated_at'>) => apiClient.createGoal(goal),
  },
  analytics: {
    get: (userId: string) => apiClient.getAnalytics(userId),
  },
  focusSessions: {
    create: (session: Omit<FocusSession, 'id'>) => apiClient.createFocusSession(session),
    getAll: (userId: string, limit?: number) => apiClient.getFocusSessions(userId, limit),
  },
  calendar: {
    getEvents: (userId: string) => apiClient.getCalendarEvents(userId),
  },
  ai: {
    generateStudyPlan: (userId: string, preferences: any) => apiClient.generateStudyPlan(userId, preferences),
    estimateTaskDuration: (taskInfo: any) => apiClient.estimateTaskDuration(taskInfo),
    suggestTimeSlots: (userId: string, requirements: any) => apiClient.suggestTimeSlots(userId, requirements),
    askAssistant: (userId: string, question: string) => apiClient.askStudyAssistant(userId, question),
  },
});

export default apiClient;