import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import Tasks from '@/pages/Tasks';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

// Mock hooks
vi.mock('@/contexts/AuthContext');
vi.mock('@/hooks/use-toast');

const mockUser = {
  id: 'test-user-id',
  email: 'test@example.com',
  name: 'Test User',
};

const mockTasks = [
  {
    id: '1',
    user_id: 'test-user-id',
    title: 'Test Task 1',
    description: 'Description for task 1',
    priority: 'high' as const,
    status: 'todo' as const,
    category: 'Math',
    due_date: '2024-12-31T23:59:59Z',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    user_id: 'test-user-id',
    title: 'Test Task 2',
    description: 'Description for task 2',
    priority: 'medium' as const,
    status: 'completed' as const,
    category: 'Science',
    due_date: '2024-12-25T23:59:59Z',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z',
  },
];

describe('Tasks Component', () => {
  const mockToast = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    
    // Mock auth context
    (useAuth as any).mockReturnValue({
      user: mockUser,
    });

    // Mock toast
    (useToast as any).mockReturnValue({
      toast: mockToast,
    });

    // Mock Supabase calls
    const mockSelect = vi.fn().mockReturnValue({
      eq: vi.fn().mockReturnValue({
        order: vi.fn().mockResolvedValue({
          data: mockTasks,
          error: null,
        }),
      }),
    });

    const mockInsert = vi.fn().mockReturnValue({
      select: vi.fn().mockReturnValue({
        single: vi.fn().mockResolvedValue({
          data: { ...mockTasks[0], id: '3' },
          error: null,
        }),
      }),
    });

    const mockUpdate = vi.fn().mockReturnValue({
      eq: vi.fn().mockReturnValue({
        select: vi.fn().mockReturnValue({
          single: vi.fn().mockResolvedValue({
            data: { ...mockTasks[0], status: 'completed' },
            error: null,
          }),
        }),
      }),
    });

    const mockDelete = vi.fn().mockReturnValue({
      eq: vi.fn().mockResolvedValue({
        error: null,
      }),
    });

    (supabase.from as any).mockImplementation((table: string) => {
      switch (table) {
        case 'tasks':
          return {
            select: mockSelect,
            insert: mockInsert,
            update: mockUpdate,
            delete: mockDelete,
          };
        default:
          return {
            select: vi.fn(),
            insert: vi.fn(),
            update: vi.fn(),
            delete: vi.fn(),
          };
      }
    });
  });

  it('renders tasks page correctly', async () => {
    render(<Tasks />);
    
    expect(screen.getByText('Task Management')).toBeInTheDocument();
    expect(screen.getByText('Tasks')).toBeInTheDocument();
    expect(screen.getByText('Manage and prioritize your assignments')).toBeInTheDocument();
  });

  it('displays active and completed tasks', async () => {
    render(<Tasks />);
    
    await waitFor(() => {
      expect(screen.getByText('Active Tasks (1)')).toBeInTheDocument();
      expect(screen.getByText('Completed Tasks (1)')).toBeInTheDocument();
    });
  });

  it('opens task creation dialog', async () => {
    render(<Tasks />);
    
    const addTaskButton = screen.getByText('Add Task');
    fireEvent.click(addTaskButton);
    
    expect(screen.getByText('Create New Task')).toBeInTheDocument();
    expect(screen.getByLabelText('Task Title *')).toBeInTheDocument();
  });

  it('creates a new task', async () => {
    render(<Tasks />);
    
    // Open dialog
    const addTaskButton = screen.getByText('Add Task');
    fireEvent.click(addTaskButton);
    
    // Fill form
    const titleInput = screen.getByLabelText('Task Title *');
    const descriptionInput = screen.getByLabelText('Description');
    const prioritySelect = screen.getByRole('combobox');
    
    fireEvent.change(titleInput, { target: { value: 'New Task' } });
    fireEvent.change(descriptionInput, { target: { value: 'Task description' } });
    fireEvent.change(prioritySelect, { target: { value: 'high' } });
    
    // Submit form
    const createButton = screen.getByText('Create Task');
    fireEvent.click(createButton);
    
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith({
        title: 'Task created!',
        description: 'Visit the Calendar to schedule it with AI',
      });
    });
  });

  it('toggles task completion status', async () => {
    render(<Tasks />);
    
    await waitFor(() => {
      expect(screen.getByText('Test Task 1')).toBeInTheDocument();
    });
    
    const checkbox = screen.getByRole('checkbox');
    fireEvent.click(checkbox);
    
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith({
        title: 'Task completed!',
        description: 'Great job! Keep up the momentum.',
      });
    });
  });

  it('deletes a task', async () => {
    render(<Tasks />);
    
    await waitFor(() => {
      expect(screen.getByText('Test Task 1')).toBeInTheDocument();
    });
    
    const deleteButton = screen.getByRole('button', { name: /delete/i });
    fireEvent.click(deleteButton);
    
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith({
        title: 'Task deleted successfully',
      });
    });
  });

  it('shows empty state when no tasks', async () => {
    // Mock empty tasks
    (supabase.from as any).mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockReturnValue({
          order: vi.fn().mockResolvedValue({
            data: [],
            error: null,
          }),
        }),
      }),
    });
    
    render(<Tasks />);
    
    await waitFor(() => {
      expect(screen.getByText('No active tasks')).toBeInTheDocument();
      expect(screen.getByText('Create your first task to get started!')).toBeInTheDocument();
    });
  });

  it('handles API errors gracefully', async () => {
    // Mock error
    (supabase.from as any).mockReturnValue({
      select: vi.fn().mockReturnValue({
        eq: vi.fn().mockReturnValue({
          order: vi.fn().mockResolvedValue({
            data: null,
            error: { message: 'Database error' },
          }),
        }),
      }),
    });
    
    render(<Tasks />);
    
    await waitFor(() => {
      expect(mockToast).toHaveBeenCalledWith({
        title: 'Error',
        description: 'Failed to load tasks',
        variant: 'destructive',
      });
    });
  });

  it('validates task creation form', async () => {
    render(<Tasks />);
    
    // Open dialog
    const addTaskButton = screen.getByText('Add Task');
    fireEvent.click(addTaskButton);
    
    // Try to create task without title
    const createButton = screen.getByText('Create Task');
    fireEvent.click(createButton);
    
    expect(mockToast).toHaveBeenCalledWith({
      title: 'Please enter a task title',
      variant: 'destructive',
    });
  });

  it('displays task priority badges', async () => {
    render(<Tasks />);
    
    await waitFor(() => {
      expect(screen.getByText('high')).toBeInTheDocument();
      expect(screen.getByText('medium')).toBeInTheDocument();
    });
  });

  it('shows due date information', async () => {
    render(<Tasks />);
    
    await waitFor(() => {
      expect(screen.getByText(/Math/)).toBeInTheDocument();
      expect(screen.getByText(/Due in/)).toBeInTheDocument();
    });
  });
});