#!/bin/bash

# StudyFlow Development Setup Script
# This script helps set up the development environment for StudyFlow

set -e  # Exit on any error

echo "🚀 Setting up StudyFlow Development Environment..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Check if Node.js is installed
check_nodejs() {
    print_info "Checking Node.js installation..."
    
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version)
        print_success "Node.js found: $NODE_VERSION"
        
        # Check if version is >= 18
        NODE_MAJOR=$(echo $NODE_VERSION | cut -d'.' -f1 | sed 's/v//')
        if [ "$NODE_MAJOR" -lt 18 ]; then
            print_error "Node.js version 18 or higher is required. Current version: $NODE_VERSION"
            echo "Please install Node.js 18+ from https://nodejs.org/"
            exit 1
        fi
    else
        print_error "Node.js is not installed. Please install Node.js 18+ from https://nodejs.org/"
        exit 1
    fi
}

# Check if npm is installed
check_npm() {
    print_info "Checking npm installation..."
    
    if command -v npm &> /dev/null; then
        NPM_VERSION=$(npm --version)
        print_success "npm found: $NPM_VERSION"
    else
        print_error "npm is not installed. Please install npm."
        exit 1
    fi
}

# Install dependencies
install_dependencies() {
    print_info "Installing project dependencies..."
    
    if npm install; then
        print_success "Dependencies installed successfully"
    else
        print_error "Failed to install dependencies"
        exit 1
    fi
}

# Setup environment file
setup_env() {
    print_info "Setting up environment configuration..."
    
    if [ ! -f ".env.local" ]; then
        if [ -f ".env.example" ]; then
            cp .env.example .env.local
            print_success "Created .env.local from .env.example"
            print_warning "Please update .env.local with your actual configuration values"
        else
            print_error ".env.example file not found"
            exit 1
        fi
    else
        print_warning ".env.local already exists. Skipping environment setup."
    fi
}

# Check Supabase CLI
check_supabase() {
    print_info "Checking Supabase CLI..."
    
    if command -v supabase &> /dev/null; then
        SUPABASE_VERSION=$(supabase --version)
        print_success "Supabase CLI found: $SUPABASE_VERSION"
    else
        print_warning "Supabase CLI not found. Installing..."
        
        # Install Supabase CLI
        if command -v brew &> /dev/null; then
            brew install supabase/tap/supabase
        elif command -v npm &> /dev/null; then
            npm install -g supabase
        else
            print_error "Please install Supabase CLI manually: https://supabase.com/docs/reference/cli"
            exit 1
        fi
        
        print_success "Supabase CLI installed"
    fi
}

# Setup Supabase
setup_supabase() {
    print_info "Setting up Supabase..."
    
    if [ ! -d "supabase" ]; then
        print_error "Supabase configuration not found. Please ensure you're in the project root."
        exit 1
    fi
    
    # Check if already linked
    if supabase status &> /dev/null; then
        print_success "Supabase is already set up"
    else
        print_info "Please link your Supabase project:"
        echo "Run: supabase link --project-ref your-project-ref"
        echo "Then run: supabase start"
        print_warning "After linking, run 'supabase db push' to apply migrations"
    fi
}

# Run tests
run_tests() {
    print_info "Running tests..."
    
    if npm run test; then
        print_success "All tests passed"
    else
        print_warning "Some tests failed. You can run tests later with 'npm test'"
    fi
}

# Build check
check_build() {
    print_info "Testing build process..."
    
    if npm run build; then
        print_success "Build completed successfully"
    else
        print_error "Build failed"
        exit 1
    fi
}

# Start development server
start_dev_server() {
    print_info "Starting development server..."
    print_success "StudyFlow is ready! 🎉"
    echo ""
    echo "📝 Next steps:"
    echo "1. Update .env.local with your Supabase configuration"
    echo "2. Link your Supabase project if not already done"
    echo "3. Run 'supabase db push' to apply database migrations"
    echo "4. Start the dev server with 'npm run dev'"
    echo ""
    echo "🌐 The application will be available at: http://localhost:5173"
    echo ""
    
    # Ask if user wants to start dev server
    read -p "Do you want to start the development server now? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        npm run dev
    fi
}

# Main setup function
main() {
    echo "🎯 StudyFlow Development Setup"
    echo "=============================="
    echo ""
    
    check_nodejs
    check_npm
    install_dependencies
    setup_env
    check_supabase
    setup_supabase
    
    # Optional steps
    echo ""
    read -p "Do you want to run tests? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        run_tests
    fi
    
    echo ""
    read -p "Do you want to test the build process? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        check_build
    fi
    
    start_dev_server
}

# Handle script arguments
case "$1" in
    --help|-h)
        echo "StudyFlow Development Setup Script"
        echo ""
        echo "Usage: $0 [options]"
        echo ""
        echo "Options:"
        echo "  --help, -h     Show this help message"
        echo "  --no-deps      Skip dependency installation"
        echo "  --no-tests     Skip running tests"
        echo "  --no-build     Skip build check"
        echo "  --quiet        Run with minimal output"
        echo ""
        exit 0
        ;;
    --no-deps)
        print_warning "Skipping dependency installation"
        unset install_dependencies
        ;;
    --no-tests)
        print_warning "Skipping tests"
        unset run_tests
        ;;
    --no-build)
        print_warning "Skipping build check"
        unset check_build
        ;;
esac

# Run main setup
main