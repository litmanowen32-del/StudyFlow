# Google Classroom Integration Setup Guide

This guide will help you set up Google Classroom integration to automatically sync assignments to the StudyFlow calendar.

## 🚀 Overview

The Google Classroom integration allows users to:
- Connect their Google Classroom account
- Automatically sync assignments to their calendar
- Get notifications for upcoming deadlines
- Track progress across all courses

## 📋 Prerequisites

1. **Google Cloud Project**: You need a Google Cloud project with Google Classroom API enabled
2. **OAuth Credentials**: Client ID and Client Secret for web application
3. **Supabase Project**: With Edge Functions enabled
4. **Environment Variables**: Properly configured in your application

## 🔧 Step 1: Google Cloud Setup

### 1.1 Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable billing (required for Google APIs)

### 1.2 Enable APIs

Enable the following APIs in your Google Cloud project:

```bash
# Enable Google Classroom API
gcloud services enable classroom.googleapis.com

# Enable Google Calendar API
gcloud services enable calendar.googleapis.com

# Enable Google OAuth2 API
gcloud services enable oauth2.googleapis.com
```

Or do it manually:
1. Go to "APIs & Services" > "Library"
2. Search and enable:
   - Google Classroom API
   - Google Calendar API
   - Google OAuth2 API

### 1.3 Create OAuth Credentials

1. Go to "APIs & Services" > "Credentials"
2. Click "Create Credentials" > "OAuth client ID"
3. Select "Web application" as application type
4. Add authorized redirect URIs:
   ```
   https://your-domain.com/auth/google/callback
   http://localhost:5173/auth/google/callback  # For development
   ```
5. Save the Client ID and Client Secret

## 🔧 Step 2: Supabase Setup

### 2.1 Enable Edge Functions

```bash
# Install Supabase CLI
npm install -g supabase

# Link to your project
supabase link --project-ref your-project-ref

# Start local development
supabase start
```

### 2.2 Set Environment Variables

Add these environment variables to your Supabase project:

```bash
# Google OAuth Configuration
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret

# Your application URL
SITE_URL=https://your-domain.com
```

You can set them via:
- Supabase Dashboard: Settings > Edge Functions > Secrets
- Or CLI: `supabase secrets set GOOGLE_CLIENT_ID=your-id`

### 2.3 Deploy Edge Functions

```bash
# Deploy the Google Classroom functions
supabase functions deploy google-classroom-auth
supabase functions deploy sync-google-classroom
supabase functions deploy store-google-credentials
supabase functions deploy clear-google-credentials
supabase functions deploy exchange-google-code
supabase functions deploy get-google-tokens
```

### 2.4 Run Database Migrations

```bash
# Apply the Google Classroom migration
supabase db push
```

## 🔧 Step 3: Application Setup

### 3.1 Environment Variables

Add these to your `.env.local` file:

```env
# Google OAuth Configuration
VITE_GOOGLE_CLIENT_ID=your-google-client-id

# Optional: Google Client Secret (for server-side operations)
VITE_GOOGLE_CLIENT_SECRET=your-google-client-secret

# Your application URLs
VITE_SITE_URL=https://your-domain.com
VITE_REDIRECT_URL=https://your-domain.com/auth/google/callback
```

### 3.2 Install Dependencies

The integration uses these additional packages (already included):

```json
{
  "dependencies": {
    // ... existing dependencies
  }
}
```

### 3.3 Configure Application

The integration is already configured in the codebase:
- `src/services/googleClassroom.ts` - Google Classroom API service
- `src/components/GoogleAuth.tsx` - Authentication component
- `src/pages/GoogleCallback.tsx` - OAuth callback handler
- `src/pages/Calendar.tsx` - Updated calendar with Google Classroom integration

## 🔧 Step 4: Testing the Integration

### 4.1 Local Testing

1. Start your development server:
   ```bash
   npm run dev
   ```

2. Navigate to the Calendar page
3. Click "Connect Google Classroom"
4. Complete the OAuth flow
5. Verify assignments sync to your calendar

### 4.2 Production Testing

1. Deploy your application to production
2. Update your Google OAuth redirect URIs to include your production URL
3. Test the connection flow in production
4. Verify that assignments appear in Google Calendar

## 📊 How It Works

### Authentication Flow

1. User clicks "Connect Google Classroom"
2. Opens Google OAuth popup with proper scopes
3. User grants permission
4. Authorization code is sent to callback
5. Code is exchanged for access/refresh tokens
6. Tokens are stored securely in database

### Sync Process

1. User clicks "Sync Now" or auto-sync triggers
2. Edge function fetches Google Classroom courses
3. For each course, fetches assignments
4. Converts assignments to calendar events
5. Adds events to user's Google Calendar
6. Stores assignments in local database for tracking

### Data Storage

- **user_google_credentials**: OAuth tokens (encrypted)
- **google_classroom_assignments**: Synced assignments
- **user_settings**: Connection status and preferences

## 🔒 Security Considerations

### Token Security

- Access tokens are stored encrypted in database
- Refresh tokens allow automatic token renewal
- Tokens have limited scope (read-only access)
- Proper expiration handling

### Data Privacy

- Only assignment data is accessed (no personal student info)
- Data is stored with user's consent
- Users can disconnect at any time
- Row-level security ensures data isolation

### API Security

- Edge functions validate user authentication
- Proper CORS configuration
- Rate limiting to prevent abuse
- Error handling prevents information leakage

## 🚨 Troubleshooting

### Common Issues

#### "Google Integration Not Configured"
- Verify `VITE_GOOGLE_CLIENT_ID` is set
- Check Google Cloud project has Classroom API enabled
- Ensure redirect URIs match exactly

#### "Authentication Failed"
- Check OAuth credentials are correct
- Verify redirect URI in Google Console matches your app
- Ensure Edge Functions are deployed

#### "Failed to sync assignments"
- Check if user has active Google Classroom courses
- Verify proper API permissions
- Check Edge Function logs for errors

#### "Token expired"
- Ensure refresh tokens are being stored
- Check token expiration handling
- Verify proper refresh logic

### Debug Steps

1. Check browser console for errors
2. Review Edge Function logs:
   ```bash
   supabase functions logs google-classroom-auth
   supabase functions logs sync-google-classroom
   ```
3. Verify environment variables:
   ```bash
   supabase secrets list
   ```
4. Test API access manually:
   ```bash
   curl -H "Authorization: Bearer $TOKEN" \
        https://classroom.googleapis.com/v1/courses
   ```

## 📈 Monitoring and Analytics

### Key Metrics

- Connection success rate
- Assignment sync frequency
- API error rates
- User engagement metrics

### Logs to Monitor

- Authentication failures
- Sync errors
- Token refresh issues
- Rate limiting events

## 🔄 Maintenance

### Regular Tasks

- Monitor API quota usage
- Check token refresh success rate
- Update OAuth scopes if needed
- Review and rotate credentials

### Updates

- Keep Google API dependencies updated
- Monitor Google Classroom API changes
- Update redirect URIs when changing domains
- Regular security audits

## 🎯 Best Practices

### Development

- Use environment-specific redirect URIs
- Test with multiple Google Classroom accounts
- Implement proper error handling
- Use TypeScript for type safety

### Production

- Enable proper monitoring and logging
- Set up alerts for sync failures
- Implement rate limiting
- Regular security reviews

### User Experience

- Provide clear connection instructions
- Show sync progress indicators
- Offer manual sync options
- Handle connection failures gracefully

## 📚 Additional Resources

- [Google Classroom API Documentation](https://developers.google.com/classroom)
- [Google OAuth 2.0 Guide](https://developers.google.com/identity/protocols/oauth2)
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)
- [Google Calendar API](https://developers.google.com/calendar)

---

## 🆘 Support

If you encounter issues during setup:

1. Check the troubleshooting section above
2. Review Edge Function logs
3. Verify environment variables
4. Test API access manually
5. Check Google Cloud Console for API errors

For additional support, refer to the main documentation or create an issue in the repository.