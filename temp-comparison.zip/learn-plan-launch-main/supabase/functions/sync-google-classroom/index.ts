import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { userId } = await req.json();
    const targetUserId = userId || user.id;

    // Get user's Google credentials
    const { data: credentials, error: credError } = await supabaseClient
      .from('user_google_credentials')
      .select('*')
      .eq('user_id', targetUserId)
      .single();

    if (credError || !credentials) {
      throw new Error('Google Classroom not connected');
    }

    // Check if token is expired and refresh if needed
    let accessToken = credentials.access_token;
    const isExpired = new Date(credentials.expires_at) < new Date();

    if (isExpired && credentials.refresh_token) {
      // Refresh the token
      const refreshResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          client_id: Deno.env.get('GOOGLE_CLIENT_ID')!,
          client_secret: Deno.env.get('GOOGLE_CLIENT_SECRET')!,
          refresh_token: credentials.refresh_token,
          grant_type: 'refresh_token',
        }),
      });

      if (!refreshResponse.ok) {
        throw new Error('Failed to refresh access token');
      }

      const tokenData = await refreshResponse.json();
      accessToken = tokenData.access_token;

      // Update stored token
      await supabaseClient
        .from('user_google_credentials')
        .update({
          access_token: accessToken,
          expires_at: new Date(Date.now() + tokenData.expires_in * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', targetUserId);
    }

    // Fetch Google Classroom courses
    const coursesResponse = await fetch(
      'https://classroom.googleapis.com/v1/courses?courseStates=ACTIVE',
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      }
    );

    if (!coursesResponse.ok) {
      throw new Error('Failed to fetch Google Classroom courses');
    }

    const coursesData = await coursesResponse.json();
    const courses = coursesData.courses || [];

    let totalSyncedAssignments = 0;

    // Process each course
    for (const course of courses) {
      try {
        // Fetch assignments for this course
        const assignmentsResponse = await fetch(
          `https://classroom.googleapis.com/v1/courses/${course.id}/courseWork`,
          {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
            },
          }
        );

        if (!assignmentsResponse.ok) {
          console.error(`Failed to fetch assignments for course ${course.name}:`, assignmentsResponse.statusText);
          continue;
        }

        const assignmentsData = await assignmentsResponse.json();
        const assignments = assignmentsData.courseWork || [];

        // Process each assignment
        for (const assignment of assignments) {
          try {
            // Check if assignment already exists in calendar
            const existingEvent = await fetch(
              `https://www.googleapis.com/calendar/v3/calendars/primary/events?q=google-classroom:${assignment.id}`,
              {
                headers: {
                  'Authorization': `Bearer ${accessToken}`,
                },
              }
            );

            if (existingEvent.ok) {
              const existingData = await existingEvent.json();
              if (existingData.items && existingData.items.length > 0) {
                // Assignment already synced, skip
                continue;
              }
            }

            // Convert assignment to calendar event
            const calendarEvent = convertAssignmentToCalendarEvent(assignment, course);

            // Add to Google Calendar
            const calendarResponse = await fetch(
              'https://www.googleapis.com/calendar/v3/calendars/primary/events',
              {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${accessToken}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify(calendarEvent),
              }
            );

            if (calendarResponse.ok) {
              totalSyncedAssignments++;
              
              // Store assignment in our database
              await supabaseClient
                .from('google_classroom_assignments')
                .upsert({
                  user_id: targetUserId,
                  assignment_id: assignment.id,
                  course_id: course.id,
                  course_name: course.name,
                  title: assignment.title,
                  description: assignment.description,
                  due_date: assignment.dueDate 
                    ? `${assignment.dueDate.year}-${assignment.dueDate.month.toString().padStart(2, '0')}-${assignment.dueDate.day.toString().padStart(2, '0')}`
                    : null,
                  due_time: assignment.dueTime 
                    ? `${assignment.dueTime.hours.toString().padStart(2, '0')}:${assignment.dueTime.minutes.toString().padStart(2, '0')}`
                    : null,
                  state: assignment.state,
                  max_points: assignment.maxPoints,
                  link: assignment.alternateLink,
                  created_at: new Date().toISOString(),
                  updated_at: new Date().toISOString(),
                });

              // Small delay to avoid rate limiting
              await new Promise(resolve => setTimeout(resolve, 100));
            }
          } catch (assignmentError) {
            console.error(`Error processing assignment ${assignment.title}:`, assignmentError);
            // Continue with other assignments
          }
        }
      } catch (courseError) {
        console.error(`Error processing course ${course.name}:`, courseError);
        // Continue with other courses
      }
    }

    // Update last sync date
    await supabaseClient
      .from('user_settings')
      .update({
        last_sync_date: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', targetUserId);

    return new Response(
      JSON.stringify({ 
        success: true,
        message: `Successfully synced ${totalSyncedAssignments} assignments`,
        syncedAssignments: totalSyncedAssignments,
        coursesProcessed: courses.length
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in sync-google-classroom:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

function convertAssignmentToCalendarEvent(assignment: any, course: any) {
  const summary = `[Assignment] ${assignment.title}`;
  let description = `Course: ${course.name}\n`;
  
  if (assignment.description) {
    description += `\n${assignment.description}\n`;
  }
  
  if (assignment.maxPoints) {
    description += `\nPoints: ${assignment.maxPoints}\n`;
  }
  
  if (assignment.alternateLink) {
    description += `\n📚 View Assignment: ${assignment.alternateLink}\n`;
  }
  
  description += `\n---\nSynced from Google Classroom`;
  
  // Calculate due date and time
  let startDateTime: string;
  let endDateTime: string;
  
  if (assignment.dueDate) {
    const dueDate = new Date(assignment.dueDate.year, assignment.dueDate.month - 1, assignment.dueDate.day);
    
    if (assignment.dueTime) {
      dueDate.setHours(assignment.dueTime.hours, assignment.dueTime.minutes, 0, 0);
      endDateTime = dueDate.toISOString();
      
      // Start 1 hour before due time
      const startDate = new Date(dueDate.getTime() - 60 * 60 * 1000);
      startDateTime = startDate.toISOString();
    } else {
      // If no time specified, make it an all-day event
      const nextDay = new Date(dueDate.getTime() + 24 * 60 * 60 * 1000);
      startDateTime = dueDate.toISOString().split('T')[0];
      endDateTime = nextDay.toISOString().split('T')[0];
    }
  } else {
    // If no due date, schedule for tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    startDateTime = tomorrow.toISOString().split('T')[0];
    endDateTime = tomorrow.toISOString().split('T')[0];
  }
  
  return {
    summary,
    description,
    start: assignment.dueTime ? {
      dateTime: startDateTime,
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    } : {
      date: startDateTime,
    },
    end: assignment.dueTime ? {
      dateTime: endDateTime,
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    } : {
      date: endDateTime,
    },
    colorId: '11', // Red color for assignments
    reminders: {
      useDefault: false,
      overrides: [
        { method: 'popup', minutes: 1440 }, // 1 day before
        { method: 'popup', minutes: 60 }, // 1 hour before
      ],
    },
    extendedProperties: {
      private: {
        source: 'google-classroom',
        assignmentId: assignment.id,
        courseId: course.id,
      },
    },
  };
}