-- Google Classroom Integration Tables

-- User Google Credentials Table
CREATE TABLE IF NOT EXISTS user_google_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  access_token TEXT NOT NULL,
  refresh_token TEXT,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  google_email TEXT,
  google_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Google Classroom Assignments Table
CREATE TABLE IF NOT EXISTS google_classroom_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  assignment_id TEXT NOT NULL,
  course_id TEXT NOT NULL,
  course_name TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  due_date DATE,
  due_time TIME,
  state TEXT,
  max_points INTEGER,
  link TEXT,
  materials JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, assignment_id)
);

-- Update user_settings table to include Google Classroom settings
ALTER TABLE user_settings 
ADD COLUMN IF NOT EXISTS google_classroom_connected BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS google_email TEXT,
ADD COLUMN IF NOT EXISTS last_sync_date TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS auto_sync_enabled BOOLEAN DEFAULT FALSE;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_user_google_credentials_user_id ON user_google_credentials(user_id);
CREATE INDEX IF NOT EXISTS idx_google_classroom_assignments_user_id ON google_classroom_assignments(user_id);
CREATE INDEX IF NOT EXISTS idx_google_classroom_assignments_due_date ON google_classroom_assignments(due_date);
CREATE INDEX IF NOT EXISTS idx_user_settings_google_connected ON user_settings(google_classroom_connected);

-- Enable Row Level Security
ALTER TABLE user_google_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE google_classroom_assignments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_google_credentials
CREATE POLICY "Users can view own google credentials" ON user_google_credentials
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own google credentials" ON user_google_credentials
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own google credentials" ON user_google_credentials
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own google credentials" ON user_google_credentials
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for google_classroom_assignments
CREATE POLICY "Users can view own google classroom assignments" ON google_classroom_assignments
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own google classroom assignments" ON google_classroom_assignments
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own google classroom assignments" ON google_classroom_assignments
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own google classroom assignments" ON google_classroom_assignments
  FOR DELETE USING (auth.uid() = user_id);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_user_google_credentials_updated_at 
  BEFORE UPDATE ON user_google_credentials 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_google_classroom_assignments_updated_at 
  BEFORE UPDATE ON google_classroom_assignments 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create view for calendar events (combining tasks and Google Classroom assignments)
CREATE OR REPLACE VIEW calendar_events AS
SELECT 
  id,
  user_id,
  title,
  description,
  due_date,
  due_time,
  'task' as event_type,
  priority,
  status,
  created_at,
  updated_at
FROM tasks
WHERE status != 'completed'

UNION ALL

SELECT 
  id,
  user_id,
  title,
  description,
  due_date,
  due_time,
  'google_assignment' as event_type,
  CASE 
    WHEN due_date < CURRENT_DATE THEN 'urgent'
    WHEN due_date = CURRENT_DATE THEN 'high'
    WHEN due_date <= CURRENT_DATE + INTERVAL '3 days' THEN 'medium'
    ELSE 'low'
  END as priority,
  state as status,
  created_at,
  updated_at
FROM google_classroom_assignments
WHERE state NOT IN ('TURNED_IN', 'RETURNED');

-- Comments for documentation
COMMENT ON TABLE user_google_credentials IS 'Stores OAuth credentials for Google Classroom API access';
COMMENT ON TABLE google_classroom_assignments IS 'Stores synchronized assignments from Google Classroom';
COMMENT ON COLUMN user_google_credentials.expires_at IS 'When the access token expires';
COMMENT ON COLUMN google_classroom_assignments.materials IS 'JSON array of assignment materials (links, files, etc.)';
COMMENT ON VIEW calendar_events IS 'Combined view of all calendar events including tasks and Google Classroom assignments';